import java.util.Random;

public class RacingGame {
	public static void main(String[] args) {
		// 조심 HORSE_NAMES, END_DISTANCE가 너무 많으면 출력 ERROR
		final String[] HORSE_NAMES = { "김동준", "공  현", "박성민", "김경현", "정형석", "박종선", "최성욱", "권슬기" };
		final int END_DISTANCE = 150;
		final int START_HORSE_INDEX = 0;
		final int HORSE_POWER = 1;
		Random random = new Random();
		Horse[] horse = new Horse[HORSE_NAMES.length];
		for (int i = 0; i < horse.length; i++) {
			int eachCondition = random.nextInt(3) + 2;
			horse[i] = new Horse(horse, HORSE_NAMES[i], HORSE_POWER, eachCondition, END_DISTANCE, i);
		}
		horse[START_HORSE_INDEX].runHorse();
	}
}
