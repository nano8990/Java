
public class StudentScoreMainRun {
	public static void main(String[] args) {
		int totalStudent = 100;
		StudentScoreMiddle[] middlescore = new StudentScoreMiddle[totalStudent];
		StudentScoreFinal[] finalscore = new StudentScoreFinal[totalStudent];
		String name;
		for (int i = 0; i < totalStudent; i++) {
			name = (i + 1) + "번";

			middlescore[i] = new StudentScoreMiddle();
			middlescore[i].inputRandomScore();
			finalscore[i] = new StudentScoreFinal();
			finalscore[i].inputRandomScore();

			int gradeUpScore = finalscore[i].totalScore - middlescore[i].totalScore;

			if (gradeUpScore > 0) {
				System.out.printf("%s의\t중간 총점 : %d\t(국어 : %d, 영어 : %d, 수학 : %d)\t", name, middlescore[i].totalScore,
						middlescore[i].koreanScore, middlescore[i].englishScore, middlescore[i].mathScore);
				System.out.printf("기말 총점 : %d\t(국어 : %d, 영어 : %d, 수학 : %d)\t/ 올라간 성적 : %d\n", finalscore[i].totalScore,
						finalscore[i].koreanScore, finalscore[i].englishScore, finalscore[i].mathScore, gradeUpScore);
			}
		}
	}
}
