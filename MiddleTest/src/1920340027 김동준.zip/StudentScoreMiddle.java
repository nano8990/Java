import java.util.Random;

public class StudentScoreMiddle implements StudentScore {
	int koreanScore;
	int englishScore;
	int mathScore;
	int totalScore;

	public void inputRandomScore() {
		Random random = new Random();
		this.koreanScore = random.nextInt(101);
		this.englishScore = random.nextInt(101);
		this.mathScore = random.nextInt(101);
		this.totalScore = this.koreanScore + this.englishScore + this.mathScore;
	}
}
