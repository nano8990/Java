
public interface StudentScore {
	public void inputRandomScore();
}
